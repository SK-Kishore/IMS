package com.imagemanagementsystem;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class GetImagesFromServer {

    // url to post our data
    String url = "http://localhost/courseApp/addCourses.php";


}
